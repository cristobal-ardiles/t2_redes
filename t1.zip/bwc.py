from socket import socket
from struct import pack
from threading import TIMEOUT_MAX
import time
import jsockets
import sys

def exit_timeout():
    print("Fatal: no se recibió un paquete a tiempo")
    sys.exit(1)

def exit_wrong_package(expected, received):
    print(f"Fatal, received wrong package. Expected {expected}, received {received}")
    sys.exit(1)

## Intenta recibir un mensaje en un socket. 
def try_to_receive(sock, max_size, tries=1):
    sock.settimeout(MAX_SECS)
    try:
        response = sock.recv(max_size)
    except:
        exit_timeout()
    sock.settimeout(None)
    return response

MAX_PACKSIZE_DIGITS = 4
MAX_SECS = 10
N_TRIES = 10

if len(sys.argv) != 6:
    print("Use: "+sys.argv[0]+" packsize filein fileout host port")
    sys.exit(1)

packsize, filein, fileout, host, port = sys.argv[1:]

## Conexión al servidor
sv_socket = jsockets.socket_udp_connect(host, int(port))

## Preparamos el mensaje para el servidor
msg = "C"+packsize.zfill(MAX_PACKSIZE_DIGITS)
    
## Enviamos el paquete al servidor y esperamos la respuesta
t0 = time.time()
sv_socket.send(msg.encode())

## Recibimos la respuesta del servidor
response = try_to_receive(sv_socket,4096).decode()

if response[0] != "C":
    exit_wrong_package("C",response[0])

package_size = int(response[1:])
total_bytes_sent = 0
## Aquí ya tenemos el tamaño del paquete acordado 

with open(filein,"rb") as input:
    chunk = input.read(package_size)
    while chunk:
        # Creamos el mensaje como un bytearray
        msg = bytearray()
        # Agregamos D al inicio del mensaje
        msg += b"D"
        # Agregamos el trozo de archivo
        msg += chunk
        #Enviamos el mensaje
        bytes_sent = sv_socket.send(msg)
        total_bytes_sent += bytes_sent
        #Volvemos a leer un pedazo de texto
        chunk = input.read(package_size)
# Cuando se acaba el mensaje, enviamos una E
sv_socket.send(b"E")
    
# Intentamos recibir el primer paquete de vuelta
# En caso de no recibirlo, reenviamos E
sv_socket.settimeout(MAX_SECS)
n_tries = 0
total_bytes_recvd = 0
while n_tries < 10:
    try: 
        response = sv_socket.recv(package_size+1)
        break   
    except:
        sv_socket.settimeout(None)
        sv_socket.send(b"E")
        sv_socket.settimeout(MAX_SECS)
        n_tries += 1

## Si no se recibió un paquete después de 10 intentos, se abandona
if not response:
    exit_timeout()

with open(fileout,"wb") as output:
    # Obtenemos el primer byte para asegurarnos de recibir el paquete correcto
    # Recimos paquetes hasta que no sea más contenido
    while response[0] == ord("D"):
        output.write(response[1:])
        total_bytes_recvd += len(response)
        response = try_to_receive(sv_socket,package_size+1)
        
    # Si recibo una letra distinta a 'D', entonces chequeo que sea una 'E'
    if response[0] != ord("E"):
        exit_wrong_package("E",response[0])

tf = time.time()

bandwidth = (total_bytes_sent+total_bytes_recvd)/(tf-t0)
print(bandwidth/(1024*1024))
sv_socket.close()


